function y=HzToErbRate(x)
% by Matrin Cooke, adopted from MAD library

y=(21.4*log10(4.37e-3*x+1));
